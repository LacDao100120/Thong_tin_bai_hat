/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package  Server;

import com.google.gson.Gson;

import Object.Artist;
import Object.PlayList;
import Object.Song;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author Win 10
 * Step
 * build get api(connect zing mp3,getResponse,get song )
 * build rsa encrypt
 * build interface
 * connect interface vs server 
 * 
 * 
 */
public class server2 {
    public static final String key = "acOrvUS15XRW2o9JksiK1KgQ6Vbds8ZW"; 
    private static ServerSocket server = null;
    private static Socket socket = null;
    private static BufferedReader in = null;
    private static BufferedWriter out = null;
    public static void main(String[] args) {
        try {
            ZingMp3Controller controller = new ZingMp3Controller("1.7.63", "https://zingmp3.vn", key, "X5BM3w8N7MKozC0B85o4KMlzLZKhV00y", "");
            server = new ServerSocket(5000);
            System.out.println("Server started...");
            socket = server.accept();
            System.out.println("Client connected...");
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            String result = "";
            while (true) {
                // Server nhận dữ liệu từ client qua stream
                String line = in.readLine();
                if (line.equals("bye")) {
                    break;
                }
                System.out.println("Server get: " + line);
                try {
                    if(line.equals("newRelease")){
                        Gson gson= new Gson();
        
                        result = gson.toJson((ArrayList<Song>)controller.getNewRelease());
                    }
                    if(line.equals("aumy")){
                        Gson gson= new Gson();
                        ArrayList<PlayList> playlists= controller.getTop100();
                        result = gson.toJson(playlists.get(3).getSongs());
                    }
                    if(line.contains("song;")) {
                    	String[] k = line.split(";");
                    	Gson gson= new Gson();
                        
                        result = controller.getPlayer(k[1]);
                    }
                    if(line.contains("lyric;")) {
                    	String[] k = line.split(";");
                    	Gson gson= new Gson();
                        if(controller.getLyric(k[1]) != null){
                            result = gson.toJson(controller.getLyric(k[1])); 
                        }else{
                            result = "";
                        }
                        
                    }
                    if(line.contains("keyword;")) {
                    	String[] k = line.split(";");
                    	Gson gson= new Gson();
                        
                        result = gson.toJson((ArrayList<Song>)controller.getSearch(k[1]));
                    }
                    if(line.contains("author;")) {
                    	String[] k = line.split(";");
                    	Gson gson= new Gson();
                        Artist art = (Artist)controller.getArtistInfo(k[1]);
                        if(art != null){
                            result = gson.toJson(art);
                        }else{
                            result = "";
                        }
                        
                    }
                } catch (Exception ex) {
//                    Logger.getLogger(server1.class.getName()).log(Level.SEVERE, null, ex);
                	ex.printStackTrace();
                    result = "Không có kết quả\n";
                }
                out.write(result);
                out.newLine(); //newline ở đây là xuống dòng
                out.flush();
                System.out.println("Server Response:"+result);
            }
            System.out.println("Server closed connection");
            in.close();
            out.close();
            socket.close();
            server.close();

        } catch (IOException e) {
            System.err.println(e);
        }
    }

}
