package Server;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.text.Format;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import Object.Artist;
import Object.Lyric;
import Object.PlayList;
import Object.Song;
import encrypt.mh;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ZingMp3Controller {
	 public String VERSION;
	  public String URL;
	  public String SECRET_KEY;
	  public String API_KEY;
	  public String CTIME;
	  public ZingMp3Api api;
	  public JSONConverter converter;
	public ZingMp3Controller(String vERSION, String uRL, String sECRET_KEY, String aPI_KEY, String cTIME) {
		super();
		VERSION = vERSION;
		URL = uRL;
		SECRET_KEY = sECRET_KEY;
		API_KEY = aPI_KEY;
		CTIME = cTIME;
		api = new ZingMp3Api(vERSION, uRL, sECRET_KEY, aPI_KEY, cTIME);
		converter = new JSONConverter();
	}
	public Song getSong(String id) {
		String response;
		try {
                        initSig();
			response = api.getSongInfo(id);
			System.out.println(response);
			converter.setJson(response);
			JSONObject data = converter.getObject();
			Song song = new Song();
			song = converter.parseJsonObjectToSong(data);
			return song;
		} catch (IOException | ParseException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public String getPlayer(String id) {
		try {
                        initSig();
			String response = api.getSong(id);
			converter.setJson(response);
			JSONObject data = converter.getObject();
			String playerLink = (String)data.get("128");
			return playerLink;
		} catch (IOException | ParseException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
        
	public ArrayList<Song> getNewRelease() throws IOException {
		initSig();
		String response = api.getNewRelease();
		converter.setJson(response);
		JSONObject data = converter.getObject();
		ArrayList<Song> songs = new ArrayList<>();
		JSONObject obj = (JSONObject) data.get("RTChart");
		JSONArray lstSongs = (JSONArray) obj.get("items");
		for(int j = 0 ;j<lstSongs.size();j++) {
			Song s = converter.parseJsonObjectToSong((JSONObject)lstSongs.get(j));
			songs.add(s);
		}
		return songs;
	}
        public Lyric getLyric(String Id) throws IOException {
		initSig(); 
		String response = api.getLyric(Id);
		converter.setJson(response);
                Lyric lyric = new Lyric();
		JSONObject data = converter.getObject();
		if(data != null) {
			JSONArray lstWords = (JSONArray) data.get("sentences");
                        String temp="";
                        if(lstWords != null){
                            for(int j = 0 ;j<lstWords.size();j++) {
				JSONObject s = (JSONObject)lstWords.get(j);
				JSONArray words = (JSONArray) s.get("words");
		                    for(int k =0 ;k<words.size();k++){
		                        temp += (String)((JSONObject)words.get(k)).get("data")+" ";
		                    }
		                    temp+=". \n";
			}
		            lyric.setSentences(temp);
                            return lyric;
                        }
                            return null;
			
		}
		return null;
	}
	public ArrayList<PlayList> getTop100() {
                initSig();
		ArrayList<PlayList> top100s = new ArrayList<PlayList>();
		String response = api.getTop100();
		JSONArray data = JSONConverter.getObject(response);
		for(int i =0 ;i<data.size();i++) {
			 JSONObject c = (JSONObject)data.get(i);
			PlayList playlist = new PlayList();
			JSONArray songs = (JSONArray) c.get("items");
			ArrayList<Song> lstSongs = new ArrayList<>();
			for(int j = 0 ;j<songs.size();j++) {
				Song s = converter.parseJsonObjectToSong((JSONObject)songs.get(j));
				lstSongs.add(s);
			}
			
			playlist.setTitle((String)c.get("title"));
			playlist.setSongs(lstSongs);
			top100s.add(playlist);
		}
		return top100s;
	}
	public ArrayList<Song> getSearch(String keyword){
        initSig();
		String response = api.search(keyword);
		converter.setJson(response);
		JSONObject data = converter.getObject();
		ArrayList<Song> songs = new ArrayList<>();
		//Song top1 = converter.parseJsonObjectToSong((JSONObject)(data.get("top")));
		//songs.add(top1);
		JSONArray lstSongs = (JSONArray) data.get("songs");
		for(int j = 0 ;j<lstSongs.size();j++) {
			Song s = converter.parseJsonObjectToSong((JSONObject)lstSongs.get(j));
			songs.add(s);
		}
		return songs;
	}
        public Artist getArtistInfo(String word){
        	initSig();
        	Artist artist = new Artist();
    		String response = api.getArtistInfo(word);
    		converter.setJson(response);
    		JSONObject data = converter.getObject();
                if(data != null){
                    if(data.containsKey("biography")) {
    			artist.setContent((String)data.get("biography"));
    		}
    		if(data.containsKey("national")) {
    			artist.setNational((String)data.get("national"));
    		}
    		if(data.containsKey("birthday")) {
    			artist.setBirthday((String)data.get("birthday"));
    		}
    		if(data.containsKey("realname")) {
    			artist.setRealname((String)data.get("realname"));
    		}
                if(data.containsKey("id")) {
    			artist.setId((String)data.get("id"));
    		}
    		if(data.containsKey("thumbnail")) {
                        String formatLink = (String)data.get("thumbnail"); 
    			artist.setThumnail(formatLink.replace("\\", ""));
    		}
		return artist;
                }
                else{
                    return null;
                }
    		
	}
        public void initSig(){
            long time =Instant.now().toEpochMilli();
            Double d = time/1000.0;
            String time2 = String.format ("%.0f", Math.floor(d));
            this.CTIME =  time2;
            this.api.setCTIME(time2);
        }
}
