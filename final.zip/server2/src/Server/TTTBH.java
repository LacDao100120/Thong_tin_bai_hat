/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package Server;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;

import Object.Song;
import java.net.URLEncoder;

/**
 *
 * @author Admin
 */
public class TTTBH {
    
	public static final String key = "acOrvUS15XRW2o9JksiK1KgQ6Vbds8ZW"; 
    public static void main(String[] args) throws IOException, ParseException, InterruptedException {
        long time =Instant.now().toEpochMilli();
        Double d = time/1000.0;
        String time2 = String.format ("%.0f", Math.floor(d));
        ZingMp3Controller controller= new ZingMp3Controller("1.7.63", "https://zingmp3.vn", key, "X5BM3w8N7MKozC0B85o4KMlzLZKhV00y", time2);
        Gson gson = new Gson();
       // String t = gson.toJson(controller.getTop100().get(0).getSongs());
        //System.out.println(t);
        //JSONParser parse = new JSONParser();
       //<Song> songs = (ArrayList<Song>)parse.parse(t);d
      //  System.out.println("asasasas");
      //  System.out.println(gson.toJson(controller.getTop100().get(3).getSongs().get(0).getId()));
        System.out.println(controller.getArtistInfo("Bích Phương").getBirthday());

    }
}
